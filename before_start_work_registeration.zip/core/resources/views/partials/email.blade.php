@php echo $body; @endphp
