
<section class="page-header gradient-bg-two">
    <div class="banner-shape shape01"></div>
    <div class="banner-shape shape02"></div>
    <div class="banner-shape shape03"></div>
    <div class="container">
        <div class="page-header-content">
            <h2 class="title">@lang($page_title)</h2>

        </div>
    </div>
</section>

