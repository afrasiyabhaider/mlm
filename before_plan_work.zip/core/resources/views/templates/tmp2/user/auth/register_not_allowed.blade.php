<h1 class="text-muted">@lang('Registration is not available for now').</h1>
