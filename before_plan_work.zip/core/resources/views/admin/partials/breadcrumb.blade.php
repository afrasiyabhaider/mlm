<div class="page-header bg-primary">
    <div class="row align-items-center">
        <div class="col-lg-6 col-7">
        <h6 class="page-title">{{ $page_title }}</h6>
        </div>
        <div class="col-lg-6 col-5 text-right">
            @stack('breadcrumb-plugins')
        </div>
    </div>
</div>