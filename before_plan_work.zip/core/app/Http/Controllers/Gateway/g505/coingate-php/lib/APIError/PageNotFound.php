<?php

namespace CoinGate\APIError;

;

# HTTP Status 404
class PageNotFound extends NotFound
{
}
