<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="table-responsive table-responsive">
                    <table class="table align-items-center table-light">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Sl'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('TRX-ID'); ?> </th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?> </th>
                            <th scope="col"><?php echo app('translator')->get('After Balance'); ?> </th>
                            <th scope="col"><?php echo app('translator')->get('Detail'); ?> </th>
                            <th scope="col"><?php echo app('translator')->get('Time'); ?> </th>
                        </tr>
                        </thead>
                        <tbody class="list">
                        <?php $__empty_1 = true; $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($table->firstItem()+$key); ?></td>
                                <td><?php echo e($data->trx); ?></td>
                                <td><?php echo e($general->cur_sym); ?><?php echo e(formatter_money($data->amount)); ?></td>
                                <td><?php echo e($general->cur_sym); ?><?php echo e(formatter_money($data->balance)); ?></td>
                                <td><?php echo e($data->title); ?></td>

                                <td><?php echo e(show_datetime($data->created_at)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__('NO DATA FOUND')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">

                        <?php echo e($table->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/templates/tmp2//user/trans_history.blade.php ENDPATH**/ ?>