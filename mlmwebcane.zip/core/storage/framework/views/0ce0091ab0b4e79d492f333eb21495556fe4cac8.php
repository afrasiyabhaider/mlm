<?php $__env->startSection('panel'); ?>
    <div class="col-lg-12">
        <div class="card">
            <form action="<?php echo e(route('admin.frontend.update', $titles->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label>Copyright</label>
                        <input type="text" name="title" class="form-control" placeholder="Section Title" value="<?php echo e($titles->value->title); ?>">
                    </div>
                    <div class="form-group">
                        <label>Foorter About</label>
                        <input type="text" name="subtitle" class="form-control"  placeholder="Section Sub-Title" value="<?php echo e($titles->value->subtitle); ?>">
                    </div>
                </div>
                <div class="card-footer py-4">
                    <button type="submit" class="btn btn-block btn-primary mr-2">Update</button>
                </div>
            </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\50dollarbtc\core\resources\views/admin/frontend/footer_section.blade.php ENDPATH**/ ?>