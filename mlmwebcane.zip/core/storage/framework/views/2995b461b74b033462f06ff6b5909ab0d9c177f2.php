

<?php $__env->startSection('panel'); ?>


    <div class="row">

        <div class="col-lg-12">
            <div class="card">
                <div class="table-responsive table-responsive-xl">
                    <table class="table align-items-center table-light">
                        <thead>
                        <tr>
                            <?php if(request()->path() == 'admin/used-pin'): ?>
                                <th scope="col">User</th>
                                <th scope="col">Amount</th>
                                <th scope="col">PIN</th>
                                <th scope="col">Used At</th>
                            <?php elseif(request()->path() == 'admin/manage-pin'): ?>
                                <th scope="col">Amount</th>
                                <th scope="col">PIN</th>
                            <?php endif; ?>

                        </tr>
                        </thead>


                        <tbody class="list">
                        <?php if(request()->path() == 'admin/used-pin'): ?>
                            <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('admin.users.detail', $p->pin_user->id)); ?>"><?php echo e($p->pin_user->fullname); ?></a></td>
                                    <td><?php echo e($general->cur_sym); ?><?php echo e($p->amount); ?></td>
                                    <td><?php echo e($p->pin); ?></td>
                                    <td><?php echo e($p->updated_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(request()->path() == 'admin/manage-pin'): ?>
                            <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($general->cur_sym); ?><?php echo e($p->amount); ?></td>
                                    <td><?php echo e($p->pin); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                        </tbody>




                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">
                        <?php echo e($trans->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title bold uppercase" id="myModalLabel"><?php echo app('translator')->get('Generate E-PIN'); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo e(route('admin.storePin')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">


                        <div class="form-group error">
                            <label for="inputName" class="col-sm-12  bold uppercase"><?php echo app('translator')->get('Amount'); ?> : </label>
                            <div class="col-sm-12">
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" name="amount">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                             <?php echo e($general->cur_sym); ?>

                                            </span>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="form-group error">
                            <label for="inputName" class="col-sm-12 bold uppercase"><?php echo app('translator')->get('Number (How Many Pins want to create)'); ?>: </label>
                            <div class="col-sm-12">
                                <input type="number" class="form-control has-error bold" name="number" >
                                <code><?php echo app('translator')->get('PIN will generate automatically'); ?></code>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary bold uppercase"> <?php echo app('translator')->get('Generate'); ?> </button>
                    </div>
                </form>
            </div>
        </div>
    </div>






<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>

    <?php if(request()->path() == 'admin/manage-pin'): ?>
        <button data-toggle="modal" data-target="#myModal" class="btn btn-success"><i class="fa fa-fw fa-plus"></i> <?php echo app('translator')->get('Add New'); ?> </button>
    <?php endif; ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>






<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/admin/epin/e_pin.blade.php ENDPATH**/ ?>