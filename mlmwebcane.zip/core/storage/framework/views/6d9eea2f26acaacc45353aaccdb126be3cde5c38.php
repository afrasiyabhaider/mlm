<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <form action="<?php echo e(route('admin.setting.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-row">

                        <div class="form-group col-md-4">
                            <label>Site Title</label>
                            <input type="text" class="form-control" placeholder="Your Company Title" name="sitename" value="<?php echo e($general_setting->sitename); ?>" />
                        </div>
                        <div class="form-group col-md-4">
                            <label>Currency</label>
                            <input type="text" class="form-control" placeholder="Your Transaction Currency" name="cur_text" value="<?php echo e($general_setting->cur_text); ?>" />
                        </div>
                        <div class="form-group col-md-4">
                            <label>Currency Symbol</label>
                            <input type="text" class="form-control" placeholder="Your Currency Symbol" name="cur_sym" value="<?php echo e($general_setting->cur_sym); ?>" />
                        </div>
                    </div>

                        <div class="form-row">

                            <div class="form-group col-md-2">
                                <label>Balance Transfer Charge
                                </label>
                                  <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Balance Transfer Charge" name="bal_trans_per_charge" value="<?php echo e($general_setting->bal_trans_per_charge); ?>">
                                    <div class="input-group-append">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>

                            </div>


                            <div class="form-group col-md-2">
                                <label>Fixed Charge</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><?php echo e($general_setting->cur_sym); ?></span>
                                    </div>
                                    <input type="text" class="form-control" name="bal_trans_fixed_charge" value="<?php echo e($general_setting->bal_trans_fixed_charge); ?>">

                                </div>
                            </div>
                            <div class="form-group col-md-2">
                                <label>Alert UI</label>
                                <select name="alert" class="form-control select2">
                                    <option value="0" <?php if($general_setting->alert == 0): ?> selected <?php endif; ?>>No Alert</option>
                                    <option value="1" <?php if($general_setting->alert == 1): ?> selected <?php endif; ?>>iziTOAST</option>
                                    <option value="2" <?php if($general_setting->alert == 2): ?> selected <?php endif; ?>>Toaster</option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label>Site Base Color</label>
                                <div class="input-group">
                                <span class="input-group-addon ">
                                    <input type='text' class="form-control colorPicker" value="<?php echo e($general_setting->bclr); ?>"/>
                                </span>
                                    <input type="text" class="form-control colorCode" name="bclr" value="<?php echo e($general_setting->bclr); ?>" />
                                </div>
                            </div>
                            <div class="form-group col-md-3">
                                <label>Site Secondary Color</label>
                                <div class="input-group">
                                <span class="input-group-addon">
                                    <input type='text' class="form-control colorPicker" value="<?php echo e($general_setting->sclr); ?>"/>
                                </span>
                                    <input type="text" class="form-control colorCode" name="sclr" value="<?php echo e($general_setting->sclr); ?>" />
                                </div>
                            </div>

                        </div>


                        <div class="form-row">
                        <div class="form-group col">
                            <p class="text-muted">Email Verification</p>
                            <input type="checkbox" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disable" name="ev" <?php if($general_setting->ev): ?> checked <?php endif; ?>>
                        </div>
                        <div class="form-group col">
                            <p class="text-muted">Email Notification</p>
                            <input type="checkbox" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disable" name="en" <?php if($general_setting->en): ?> checked <?php endif; ?>>
                        </div>
                        <div class="form-group col">
                            <p class="text-muted">SMS Verification</p>
                            <input type="checkbox" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disable" name="sv" <?php if($general_setting->sv): ?> checked <?php endif; ?>>
                        </div>
                        <div class="form-group col">
                            <p class="text-muted">SMS Notification</p>
                            <input type="checkbox" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disable" name="sn" <?php if($general_setting->sn): ?> checked <?php endif; ?>>
                        </div>
                        <div class="form-group col">
                            <p class="text-muted">User Registration</p>
                            <input type="checkbox" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disabled" name="reg" <?php if($general_setting->reg): ?> checked <?php endif; ?>>
                        </div>
                    </div>


                </div>
                <div class="card-footer">
                    <div class="form-row">
                        <div class="form-group col-md-12 text-center">
                            <button type="submit" class="btn btn-block btn-primary mr-2">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/admin/js/spectrum.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
<style>
.sp-replacer {
    padding: 0;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: 5px 0 0 5px;
    border-right: none;
}
.sp-preview {
    width: 100px;
    height: 44px;
    border: 0;
}

.sp-preview-inner {
    width: 110px;
}

.sp-dd{
    display: none;
}

.input-group > .form-control:not(:first-child) {
    border-top-left-radius: 0 !important;
    border-bottom-left-radius: 0 !important;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/spectrum.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $('.colorPicker').spectrum({
        color: $(this).data('color'),
        change: function (color) {
            $(this).parent().siblings('.colorCode').val(color.toHexString().replace(/^#?/, ''));
        }
    });

    $('.colorCode').on('input', function() {
        var clr = $(this).val();
        $(this).parents('.input-group').find('.colorPicker').spectrum({
            color: clr,
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\50dollarbtc\core\resources\views/admin/setting/general_setting.blade.php ENDPATH**/ ?>