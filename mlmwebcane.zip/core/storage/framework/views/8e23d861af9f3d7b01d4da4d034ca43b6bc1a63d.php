
<?php $__env->startSection('style'); ?>
    <style>
        .form-control-lg{
            padding: 20px 12px;
            background: #000000;
            color: red;
            font-weight: 700;
            font-size: 30px;
        }

        .form-control:focus {
            color: #ff0000;
            background-color: #000000;
            border-color: #ff0000;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('panel'); ?>



    <div class="row">

        <div class="col-md-6">
            <div class="card ">
                <h3 class="card-header "> <?php echo app('translator')->get($page_title); ?></h3>
                <form id="frmProducts" method="post" action="<?php echo e(route('admin.plan.store')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="card-body table-responsive">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <strong><?php echo app('translator')->get('Plan Name'); ?>:</strong>
                                    <input type="text" class="form-control form-control-lg"  name="name" placeholder="Name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <strong><?php echo app('translator')->get('Plan Price'); ?>:</strong>
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-lg plan-price'" id="plan_price"    name="price"  placeholder="<?php echo app('translator')->get('Plan Price'); ?>" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text"><?php echo e($general->cur_sym); ?></span>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <strong><?php echo app('translator')->get('Referral Bonus'); ?>:</strong>
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-lg "   name="ref_bonus"   placeholder="<?php echo app('translator')->get('Referral Bonus'); ?>" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text"><?php echo e($general->cur_sym); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12 pb-4"><h4>Level Commissions</h4></div>

                            <?php if(intval($general->matrix_height)): ?>
                                <?php for($i = 1; $i <= intval($general->matrix_height); $i++): ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <strong><?php echo app('translator')->get('Level '.$i.' Commission'); ?>:</strong>
                                            <div class="input-group">
                                                <input type="text" class="form-control form-control-lg planamountsum" onkeyup="testcalc()"   name="amount[]"  placeholder="<?php echo app('translator')->get('Amount'); ?>" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text"><?php echo e($general->cur_sym); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            <?php endif; ?>
                        </div>
                    </div>


                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-success btn-block bold uppercase"><i class="fa fa-send"></i> <?php echo app('translator')->get('Save'); ?></button>
                </div>
                </form>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-dark">
                <h3 class="card-header text-white"><?php echo app('translator')->get('Profit/Loss Calculation'); ?></h3>
               <div class="card-body">
                   <div class="row  mt-50">
                       <div class="col-md-12">
                           <div class="alert alert-secondary text-center" id="giveStatus">
                               <h2><strong><?php echo app('translator')->get('Plan Price'); ?> : <?php echo e($general->cur_sym); ?></strong><strong id="planPrice"></strong></h2>
                               <h2><strong><?php echo app('translator')->get('Referral Commission'); ?> : <?php echo e($general->cur_sym); ?></strong><strong id="refCom"></strong></h2>
                               <h2><strong><?php echo app('translator')->get('Total Level Commission'); ?> : <?php echo e($general->cur_sym); ?></strong><strong id="totalLvlCom"></strong></h2>
                               <h1 id="profitORLoss"></h1>
                           </div>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>

    <script>

        $('#plan_price').keyup(function(){
           $('#planPrice').text($(this).val());
        });

        $('input[name=ref_bonus]').keyup(function(){
            $('#refCom').text($(this).val());
        });


        $('#profitORLoss').val();



        function testcalc(){
            var x=0;
            var planPrice   = $('#plan_price').val();
            var refBonus    = $('input[name=ref_bonus]').val();

            $('.planamountsum').each(function(e){
                if($(this).val()!=''){
                    x += +$(this).val();
                }
            })

            var totalLvlCom = $('#totalLvlCom');


            totalLvlCom.text(x);

            var total = x + Number(refBonus);

            var finalAmount = planPrice - total;

            if(planPrice > total){
                $('#giveStatus').removeClass().addClass('alert alert-success text-center')
                $('#profitORLoss').html('<strong>Admin Profit : ' + finalAmount + '<?php echo e($general->cur_sym); ?>' + '</strong>')

            }else {
                $('#giveStatus').addClass('alert alert-danger text-center')
                $('#profitORLoss').html('<strong>Admin Loss : ' + finalAmount + '<?php echo e($general->cur_sym); ?>' + '</strong>')
            }




        };
    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/admin/plan/create.blade.php ENDPATH**/ ?>