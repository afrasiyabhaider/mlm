<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) .'build/css/intlTelInput.css')); ?>">
    <style>
        .intl-tel-input {
            width: 100%;
        }

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('panel'); ?>

    <div class="signin-section pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-6 ">
                    <div class="login-area registration-form-area">
                        <div class="login-header-wrapper text-center">
                          <a href="<?php echo e(url('/')); ?>" > <img class="logo" src="<?php echo e(get_image(config('constants.logoIcon.path') .'/logo.png')); ?>"
                                 alt="image"> </a>
                            <p class="text-center admin-brand-text"><?php echo app('translator')->get('User Sign Up'); ?></p>
                        </div>
                        <form action="<?php echo e(route('user.register')); ?>" method="POST" class="login-form" id="recaptchaForm">
                            <?php echo csrf_field(); ?>
                            <div class="login-inner-block">

                                    <div class="form-row">

                                        <?php if(isset($ref_user)): ?>

                                            <div class="frm-grp form-group col-md-12">

                                                <label><?php echo app('translator')->get('Referred By'); ?></label>
                                                <input style="background: #b6b9c1" type="text" value="<?php echo e($ref_user->fullname); ?>"

                                                       disabled readonly required>
                                                <input type="hidden" value="<?php echo e($ref_user->id); ?>" name="ref_id">

                                            </div>
                                            <?php else: ?>
                                                <input type="hidden" value="0" name="ref_id">

                                                <?php endif; ?>


                                        <div class="frm-grp form-group col-md-6">

                                            <label><?php echo app('translator')->get('Your first name'); ?></label>
                                            <input type="text" value="<?php echo e(old('firstname')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your first name'); ?>"
                                                   name="firstname">
                                        </div>

                                        <div class="frm-grp form-group col-md-6">

                                            <label><?php echo app('translator')->get('Your last name'); ?></label>
                                            <input type="text" value="<?php echo e(old('lastname')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your last name'); ?>"
                                                   name="lastname">
                                        </div>


                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Your email'); ?></label>
                                            <input type="text" value="<?php echo e(old('email')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your email'); ?>"
                                                   name="email">
                                        </div>

                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Your mobile'); ?></label>
                                            <input type="text" value="<?php echo e(old('mobile')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your mobile number'); ?>"
                                                   name="mobile">
                                        </div>
                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Your Country'); ?></label>

                                            <select class="frm-grp" name="country">
                                                <?php echo $__env->make('partials.country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                            </select>
                                        </div>

                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Your Username'); ?></label>
                                            <input type="text" name="username"
                                                   value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Enter your username'); ?>">
                                        </div>

                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Password'); ?></label>
                                            <input type="password" name="password"
                                                   placeholder="<?php echo app('translator')->get('Enter your password'); ?>">
                                        </div>
                                        <div class="frm-grp form-group col-md-6">
                                            <label><?php echo app('translator')->get('Confirm Password'); ?></label>
                                            <input type="password" name="password_confirmation"
                                                   placeholder="<?php echo app('translator')->get('Confirm your password'); ?>">
                                        </div>
                                    </div>
                            </div>

                            <div class="btn-area text-center">
                                <button type="submit" id="recaptcha" class="submit-btn"><?php echo app('translator')->get('Sign Up'); ?></button>
                            </div>
                            <br>

                            <div class="d-flex mt-3 justify-content-between">
                                <a href="<?php echo e(route('user.password.request')); ?>" class="forget-pass"><?php echo app('translator')->get('Forget password?'); ?></a>
                                <a href="<?php echo e(route('user.login')); ?>"
                                   class="forget-pass"><?php echo app('translator')->get('Sign In'); ?></a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(activeTemplate(true) .'users/css/signin.css')); ?>">
    <style>
        .registration-form-area .frm-grp+.frm-grp {
            margin-top: 0;
        }
        .registration-form-area .frm-grp label {
            color: #98a6ad!important;
            font-weight: 400;
        }
        .registration-form-area select {
            border: 1px solid #5220c5;
            width: 100%;
            padding: 12px 20px;
            color: #ffffff;;
            z-index: 9;
            background-color: #3c139c;
            border-radius: 3px;
        }
        .registration-form-area select option {
            color: #ffffff;
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/templates/tmp2/user/auth/register.blade.php ENDPATH**/ ?>