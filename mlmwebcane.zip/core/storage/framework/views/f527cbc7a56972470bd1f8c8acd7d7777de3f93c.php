

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make(activeTemplate() .'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <section class="contact-section padding-bottom padding-top">
       
                    <div class="col-md-6">
                        <div class="contact-area">
                            <h2 class="title"><?php echo app('translator')->get('Get In Touch'); ?></h2>

                                <form class="contact-form-dynamic" action="<?php echo e(route('send.mail.contact')); ?>" method="post">
                                    <?php echo csrf_field(); ?>


                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo app('translator')->get('Your Name'); ?>" value="<?php echo e(old('name')); ?>" name="name" id="name" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" placeholder="<?php echo app('translator')->get('Your Email'); ?>" value="<?php echo e(old('email')); ?>" name="email" id="email" required>
                                </div>



                                <div class="form-group">
                                    <textarea placeholder="<?php echo app('translator')->get('Type Message'); ?>" name="message"  id="message" required><?php echo e(old('message')); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="<?php echo app('translator')->get('send message'); ?>">
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make(activeTemplate() .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/templates/tmp2/contact.blade.php ENDPATH**/ ?>