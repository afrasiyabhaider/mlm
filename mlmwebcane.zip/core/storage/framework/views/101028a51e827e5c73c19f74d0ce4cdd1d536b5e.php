

<?php $__env->startSection('panel'); ?>


    <div class="row">


        <div class="col-lg-12">
            <div class="card-header">
                <div class="row">
                    <?php for($i = 1; $i <= $general->matrix_height; $i++): ?>
                        <div class="col-md-2 pb-3">
                            <a href="<?php echo e(route('admin.users.matrix.single',['lv_no' => $i, $user->id])); ?>" class="btn btn-primary btn-block"><?php echo app('translator')->get('Level '.$i); ?></a>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="card">
                <div class="table-responsive table-responsive-xl">
                    <table class="table align-items-center table-light">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Username'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Under Position'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Ref. By'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Balance'); ?></th>

                        </tr>
                        </thead>


                        <tbody class="list">
                        <?php echo e(showUserLevel($user->id, $lv_no)); ?>

                        </tbody>




                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">


                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/admin/users/matrix_level.blade.php ENDPATH**/ ?>