<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row page-bar-btn">
        <div class="col-md-12">

            <div class="card panel-primary">
                <div class="card-header">
                    <h3 class="panel-title text-center"><?php echo app('translator')->get('Payment Confirm'); ?></h3>
                </div>

                <div class="card-body text-center">

                    <div  class="col-md-12 text-center">
                        <h3 class="text-color"> <?php echo app('translator')->get('PLEASE SEND'); ?> <br> <span style="color:red"> <?php echo app('translator')->get('EXACTLY'); ?> <span style="color: green"> <?php echo e($data->amount); ?></span> <?php echo e($data->currency); ?></span></h3><br>
                        <h4 class="text-color"><?php echo app('translator')->get('TO'); ?> <b style="color: green"> <?php echo e($data->sendto); ?></b></h4>
                        <img src="<?php echo e($data->img); ?>" alt="">
                        <h3 class="text-color" style="font-weight:bold;"><?php echo app('translator')->get('SCAN TO SEND'); ?></h3>

                        <br><hr><br>
                        <h3 style="font-weight:bold; color:red;"><?php echo app('translator')->get('You Have to Send Exact Amount of  '); ?> <?php echo e($data->currency); ?>.</h3>
                        <h5 class="text-color" style="font-weight:bold;"><?php echo app('translator')->get('Your Account will be credited automatically after 3 network confirmations. '); ?></h5>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/templates/tmp2/payment/crypto.blade.php ENDPATH**/ ?>