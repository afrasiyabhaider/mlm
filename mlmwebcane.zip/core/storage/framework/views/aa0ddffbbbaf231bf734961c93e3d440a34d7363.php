<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-body text-center border-bottom">
                    <img src="<?php echo e(get_image(config('constants.user.profile.path') .'/'. Auth::user()->image)); ?>"
                         alt="profile-image" class="user-image">
                    <h5 class="card-title mt-3"><?php echo e(Auth::user()->name); ?></h5>
                </div>
                <div class="card-body">
                    <p class="clearfix">
                        <span class="float-left"><?php echo app('translator')->get('Username'); ?></span>
                        <span class="float-right font-weight-bold"><a
                                href="<?php echo e(route('admin.users.detail', Auth::user()->id)); ?>"><?php echo e(Auth::user()->username); ?></a></span>
                    </p>
                    <p class="clearfix">
                        <span class="float-left"><?php echo app('translator')->get('E-mail'); ?></span>
                        <span class="float-right text-muted"><?php echo e(Auth::user()->email); ?></span>
                    </p>
                    <p class="clearfix">
                        <span class="float-left"><?php echo app('translator')->get('Phone'); ?></span>
                        <span class="float-right text-muted"><?php echo e(Auth::user()->mobile ?: 'Not available'); ?></span>
                    </p>
                    <p class="clearfix">
                        <span class="float-left"><?php echo app('translator')->get('Balance'); ?></span>
                        <span
                            class="float-right text-muted"><?php echo e($general->cur_sym); ?><?php echo e(formatter_money(Auth::user()->balance)); ?></span>
                    </p>


                    <?php if(auth()->user()->ref_id != 0): ?>
                        <p class="clearfix">
                            <span class="float-left"><?php echo app('translator')->get('Referred By'); ?></span>
                            <span class="float-right text-muted">

                            <span
                                class="badge badge-pill badge-info"><?php echo e(\App\User::find(auth()->user()->ref_id)->fullname); ?></span>
                    </span>
                        </p>
                    <?php endif; ?>

                    <?php if(auth()->user()->position_id != 0): ?>
                        <p class="clearfix">
                            <span class="float-left"><?php echo app('translator')->get('Position Under'); ?></span>
                            <span class="float-right text-muted">

                                <span
                                    class="badge badge-pill badge-info"><?php echo e(\App\User::find(auth()->user()->position_id)->fullname); ?></span>


                    </span>
                        </p>
                    <?php endif; ?>

                    <p class="clearfix">
                        <span class="float-left"><?php echo app('translator')->get('Status'); ?></span>
                        <span class="float-right text-muted">
                        <?php switch(Auth::user()->status):
                                case (1): ?>
                                <span class="badge badge-pill badge-success"><?php echo app('translator')->get('Active'); ?></span>
                                <?php break; ?>
                                <?php case (2): ?>
                                <span class="badge badge-pill badge-danger"><?php echo app('translator')->get('Banned'); ?></span>
                                <?php break; ?>
                            <?php endswitch; ?>
                    </span>
                    </p>

                </div>
            </div>

        </div>
        <div class="col-lg-8 col-md-8">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs nav-tabs-primary top-icon nav-justified">
                        <li class="nav-item open">
                            <a href="#0" data-target="#edit" data-toggle="pill" class="nav-link active"><i
                                    class="fa fa-pencil-square-o"></i> <span class="hidden-xs">Edit</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="#0" data-target="#messages" data-toggle="pill" class="nav-link"><i
                                    class="fa fa-key"></i> <span class="hidden-xs">Change Password</span></a>
                        </li>

                    </ul>
                    <div class="tab-content p-3">
                        <div class="tab-pane active" id="edit">

                            <form action="<?php echo e(route('user.profile.update')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="card-body">
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo app('translator')->get('First Name'); ?> <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="firstname"
                                                       value="<?php echo e(auth()->user()->firstname); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo app('translator')->get('Last Name'); ?> <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="lastname"
                                                       value="<?php echo e(auth()->user()->lastname); ?>" required>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo app('translator')->get('Email'); ?> <span class="text-danger">*</span></label>
                                                <input class="form-control" type="email"
                                                       value="<?php echo e(auth()->user()->email); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo app('translator')->get('Phone'); ?> </label>
                                                <input class="form-control" type="text" name="mobile"
                                                       value="<?php echo e(auth()->user()->mobile); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo app('translator')->get('Avatar'); ?> </label>
                                                <input class="form-control" type="file" name="image">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">

                                        <label><?php echo app('translator')->get('Address'); ?></label>
                                        <br>
                                        <small><?php echo app('translator')->get('Street'); ?></small>
                                        <input class="form-control" type="text"
                                               value="<?php echo e(auth()->user()->address->address); ?>" name="address"
                                               placeholder="Street">
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-3">
                                            <small><?php echo app('translator')->get('City'); ?></small>
                                            <input class="form-control" type="text"
                                                   value="<?php echo e(auth()->user()->address->city); ?>" name="city"
                                                   placeholder="City">
                                        </div>
                                        <div class="form-group col-lg-3">
                                            <small><?php echo app('translator')->get('State'); ?></small>
                                            <input class="form-control" type="text"
                                                   value="<?php echo e(auth()->user()->address->state); ?>" name="state"
                                                   placeholder="State">
                                        </div>
                                        <div class="form-group col-lg-3">
                                            <small><?php echo app('translator')->get('Zip/Postal'); ?></small>
                                            <input class="form-control" type="text"
                                                   value="<?php echo e(auth()->user()->address->zip); ?>" name="zip"
                                                   placeholder="Zip/Postal">
                                        </div>
                                        <div class="form-group col-lg-3">
                                            <small><?php echo app('translator')->get('Country'); ?></small>
                                            <select name="country"
                                                    class="form-control"> <?php echo $__env->make('partials.country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </select>
                                        </div>
                                    </div>


                                </div>
                                <div class="card-footer">
                                    <div class="form-group row">
                                        <div class="col-lg-12 text-center">
                                            <input type="submit" class="btn btn-block btn-primary mt-2"
                                                   value="<?php echo app('translator')->get('Save Changes'); ?>">
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <div class="tab-pane" id="messages">

                            <form action="<?php echo e(route('user.password.update')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="form-group row">
                                    <label
                                        class="col-lg-3 col-form-label form-control-label"><?php echo app('translator')->get('Current Password'); ?></label>
                                    <div class="col-lg-9">
                                        <input class="form-control" name="current" type="password" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label
                                        class="col-lg-3 col-form-label form-control-label"><?php echo app('translator')->get('New Password'); ?></label>
                                    <div class="col-lg-9">
                                        <input class="form-control" name="password" type="password" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label
                                        class="col-lg-3 col-form-label form-control-label"><?php echo app('translator')->get('Confirm Password'); ?></label>
                                    <div class="col-lg-9">
                                        <input class="form-control" name="password_confirmation" type="password"
                                               required>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label form-control-label"></label>
                                    <div class="col-lg-9">
                                        <input type="reset" class="btn btn-secondary" value="<?php echo app('translator')->get('Cancel'); ?>">
                                        <input type="submit" class="btn btn-primary" value="<?php echo app('translator')->get('Save Changes'); ?>">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
    <style>
        .user-image {
            width: 200px;
            height: 200px;
        }
    </style>

    <script>
        $("select[name=country]").val("<?php echo e(Auth::user()->address->country); ?>");
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/templates/tmp2//user/profile.blade.php ENDPATH**/ ?>