<?php $__env->startSection('content'); ?>

<!-- Home Banner -->
<section class="effect-section medium-dark-bg">
    
    
    <div class="container">
        <div class="row full-screen align-items-center p-100px-tb justify-content-center">
            <div class="col-md-7 col-lg-6 m-50px-t m-100px-b md-m-0px-b">
                <h1 class="display-4 m-10px-b white-color">New Bitcoin Earning Program</h1>
                <p class="font-2 white-color-light">Earn $1,896.00 each time your Level fills Up, Join the Simple yet powerful automated income opportunity!. Membership Spot is a one-time $50 in BTC. </p>
                <div class="p-20px-t m-btn-wide">
                    <a class="m-btn m-btn-radius m-btn-t-yellow m-10px-r" href="login.html">
                        <span class="m-btn-inner-text">Sign In</span>
                        <span class="m-btn-inner-icon arrow"></span>
                    </a>
                    <a class="m-btn m-btn-radius m-btn-white" href="register.html">
                        <span class="m-btn-inner-text">Join 50dollarbtc</span>
                        <span class="m-btn-inner-icon arrow"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-5 col-lg-6 m-50px-t m-100px-b">
                <img class="max-width-120" src="asset/images/section6_1588330731.png" title="" alt="">
            </div>
        </div>
    </div>
</section>

<section class="section gray-bg">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 m-15px-tb">
                <div class="p-45px-l lg-p-0px-l">
                    <h2 class="m-15px-b">Make Bitcoin Easily ( 3x5 Forced Matrix Plans) </h2>
                    <p class="lead">Let&#039;s Make Bitcoin Easily ( 3x5 Forced Matrix Plans). We understand that you need the best paying Bitcoin Program. You've just found 50dollarbtc the best paying bitcoin program. The Process is easy!</p>
                    <ul class="list-type-03">
                        <li>Buy Your Mmebership Spot with $50 in btc</li>
                        <li>Refer Just 3 </li>
                        <li>Earn Bitcoins in Dollars to Level 5</li>
                        <li>Simple Program - Daily Withdrawals</li>
						<li>Spillover is Available - Earn Without Refferring</li>
                    </ul>
                    <div class="p-20px-t">
                        <a class="m-btn m-btn-radius m-btn-theme m-10px-r" href="about.html">
                            <span class="m-btn-inner-text">More About</span>
                            <span class="m-btn-inner-icon arrow"></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 m-15px-tb">
                <img src="asset/images/section4_1588712247.png" title="" alt="">
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-15px-tb">
                <h3 class="h1 m-20px-b">Over 147,007 Active Users</h3>
                <p class="lead">Join over 147,007 Active Users getting paid to their Bitcoin Wallet.</p>
                <div class="p-20px-tb">
                    <div class="skill-lt md">
                        <h6 class="dark-color">Quick Instant Payout</h6>
                        <div class="skill-bar">
                            <div class="skill-bar-in dark-bg" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                                <span>Receive Instant Withdrawal Payment</span>
                            </div>
                        </div>

                    </div><!-- /skill -->
                    <div class="skill-lt md">
                        <h6 class="dark-color">Ease of use</h6>
                        <div class="skill-bar">
                            <div class="skill-bar-in yellow-bg" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                                <span>Quick Support</span>
                            </div>
                        </div>
                    </div><!-- /skill -->                    
                    <div class="skill-lt md">
                        <h6 class="dark-color">Spillover Available </h6>
                        <div class="skill-bar">
                            <div class="skill-bar-in blue-bg" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                                <span>Earn From Spillover</span>
                            </div>
                        </div>
                    </div><!-- /skill -->
                </div>
            </div>
            <div class="col-lg-6 col-xl-5 ml-lg-auto align-self-center m-15px-tb" id="faq">
                <div class="accordion accordion-08 p10 border-radius-15 dark-bg white-color-light links-white">
                                        <div class="acco-group">
                        <a href="#" class="acco-heading">What is 50dollarbtc? </a>
                        <div class="acco-des">50dollarbtc is a revolutionary Bitcoin Matrix Program, where you earn bitcoin for refering 3 people. It is a 3x5 Matrix Program, Meaning "You refer 3 and you get paid to level 5. You earn a total $1,896.00" after you complete the simple 3x5 matrix and you can re-enter again. </div>
                    </div>
                                        <div class="acco-group">
                        <a href="#" class="acco-heading">How do I Join?</a>
                        <div class="acco-des">It's easy, Membership is a one-time $50 in bitcoin - click on the register link on the menu and complete the simple registration form.</div>
                    </div>
                                        <div class="acco-group">
                        <a href="#" class="acco-heading">How do I Get paid?</a>
                        <div class="acco-des">Minimum Payout is $5, anytime you have $5 and above you can make request and get paid to your bitcoin wallet</div>
                    </div>
                                        <div class="acco-group">
                        <a href="#" class="acco-heading">Can I Have Multiple Account?</a>
                        <div class="acco-des">Yes, Multiple account is allowed.</div>
                    </div>
                                        <div class="acco-group">
                        <a href="#" class="acco-heading">Tell me about Bitcoin?</a>
                        <div class="acco-des">Lorem Ipsum is simply dummy text of the printing and industry. Lorem Ipsum has been the industry industry’s standard dummy text Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                    </div>
                                    </div>
            </div>
        </div>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row justify-content-center md-m-25px-b m-40px-b">
            <div class="col-lg-8 text-center">
                <h3 class="h1 m-15px-b">50dollar BTC is a No-nonsense Automated Best Paying System </h3>
                <p class="m-0px font-2">147,007 Active Users and counting, Join 50dollarbtc and start making bitcoin today!.</p>
            </div>
        </div>
       
                </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\50dollarbtc\core\resources\views/templates/tmp2/home.blade.php ENDPATH**/ ?>