<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="table-responsive table-responsive-xl">
                    <table class="table align-items-center table-light">
                        <thead>
                        <tr>

                            <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('TRX'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Method'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                        </tr>
                        </thead>
                        <tbody >

                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(show_datetime($item->created_at)); ?></td>
                                <td><?php echo e($item->trx); ?></td>
                                <td><?php echo e(__($item->gateway->name)); ?></td>
                                <td><?php echo e($general->cur_sym); ?><?php echo e(formatter_money($item->amount)); ?> </td>
                                <td>
                                    <?php if($item->status == 1): ?>
                                        <span class="badge badge-success"><?php echo app('translator')->get('Complete'); ?></span>
                                    <?php elseif($item->status == 2): ?>
                                        <span class="badge badge-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                    <?php elseif($item->status == 3): ?>
                                        <span class="badge badge-danger"><?php echo app('translator')->get('Reject'); ?></span>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__('NO DATA FOUND')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">
                        <?php echo e($logs->links()); ?>

                    </nav>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/templates/tmp2/user/deposit_history.blade.php ENDPATH**/ ?>