<?php $__env->startSection('content'); ?>

    <?php echo $__env->make(activeTemplate() .'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="blog-section padding-bottom padding-top">
        <div class="container">
            <div class="row justify-content-center mb-30-none">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-xl-4 col-sm-10">
                        <div class="post-item  wow slideInUp">
                            <div class="post-thumb c-thumb">
                                <a href="<?php echo e(route('singleBlog', [slug($blog->value->title) , $blog->id])); ?>">
                                    <img
                                        src="<?php echo e(get_image(config('constants.frontend.blog.post.path') .'/'. $blog->value->image)); ?>"
                                        alt="blog">
                                </a>
                            </div>
                            <div class="post-content">
                                <div class="blog-header">
                                    <h6 class="title">
                                        <a href="<?php echo e(route('singleBlog', [slug($blog->value->title) , $blog->id])); ?>"><?php echo e(__($blog->value->title)); ?></a>
                                    </h6>
                                </div>
                                <div class="meta-post">
                                    <div class="date">
                                        <a>
                                            <i class="flaticon-calendar"></i>
                                            <?php echo e(\Carbon\Carbon::parse($blog->created_at)->diffForHumans()); ?>

                                        </a>
                                    </div>

                                </div>
                                <div class="entry-content">
                                    <p><?php echo e(\Illuminate\Support\Str::limit(strip_tags($blog->value->body), 160, '...')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row justify-content-center d-block">
                <div class="col-md-12">
                    <?php echo e($blogs->links()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\50dollarbtc\core\resources\views/templates/tmp2/blog.blade.php ENDPATH**/ ?>