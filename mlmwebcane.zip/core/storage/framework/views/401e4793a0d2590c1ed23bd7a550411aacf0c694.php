

<?php $__env->startSection('panel'); ?>
    <div class="col-lg-12">
        <div class="card">
            <form action="<?php echo e(route('admin.contact.setting.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label>CONTACT PHONE</label>
                        <input type="text" name="phone" class="form-control"  value="<?php echo e($data->contact_phone); ?>">
                    </div>
                    <div class="form-group">
                        <label>CONTACT EMAIL</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e($data->contact_email); ?>">
                    </div>
                    <div class="form-group">
                        <label>CONTACT ADDRESS</label>
                        <input type="text" name="address" class="form-control"  value="<?php echo e($data->contact_address); ?>">
                    </div>

                </div>
                <div class="card-footer py-4">
                    <button type="submit" class="btn btn-block btn-primary mr-2">Update</button>
                </div>
            </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/public_html/core/resources/views/admin/setting/contact.blade.php ENDPATH**/ ?>