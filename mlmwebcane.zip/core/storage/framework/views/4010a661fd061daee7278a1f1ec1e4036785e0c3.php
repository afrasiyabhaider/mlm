<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-header">
                <div class="row">
                    <?php for($i = 1; $i <= $general->matrix_height; $i++): ?>
                        <div class="col-md-2 pb-3">
                            <a href="<?php echo e(route('user.matrix.index', ['lv_no' => $i])); ?>" class="btn btn-primary btn-block"><?php echo app('translator')->get('Level '.$i); ?></a>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="card">
                <div class="table-responsive table-responsive-xl">
                    <table class="table align-items-center table-light">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Username'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Under Position'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Ref. By'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Balance'); ?></th>

                        </tr>
                        </thead>
                        <tbody class="list">
                        <?php echo e(showUserLevel(auth()->user()->id, $lv_no)); ?>

                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/templates/tmp2//user/matrix.blade.php ENDPATH**/ ?>