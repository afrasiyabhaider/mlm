<?php $__env->startPush('style'); ?>
    <style>
        .badge {
            font-size: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center align-items-center">
        <div class="col-xl-2 col-lg-4 col-md-4">
            <div class="card text-center">
                <img src="<?php echo e(get_image(config('constants.deposit.gateway.path') .'/'. $data->gateway->image)); ?>"
                     class="card-img-top" alt="image">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Deposit Via '.$data->gateway->name); ?></h5>
                </div>


            </div>
        </div><!-- card end -->

        <div class="col-xl-6 col-lg-6 col-md-6">
            <div class="card">

                <div class="card-body bg-success">
                    <h5 class="card-title"><?php echo app('translator')->get('Preview'); ?></h5>

                </div>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="gateway" value=""/>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong><?php echo app('translator')->get('Amount'); ?> : </strong><span
                                class="badge badge-primary"><?php echo e(formatter_money($data->amount)); ?> <?php echo e($general->cur_text); ?></span>
                    </li>


                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong><?php echo app('translator')->get('Charge'); ?> : </strong><span
                                class="badge badge-danger"><?php echo e(formatter_money($data->charge)); ?> <?php echo e($general->cur_text); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong><?php echo app('translator')->get('Payable'); ?> :</strong><span
                                class="badge badge-success"><?php echo e(formatter_money($data->amount + $data->charge)); ?> <?php echo e($general->cur_text); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong><?php echo app('translator')->get('Conversion Rate'); ?> : </strong> <span
                                class="badge badge-secondary"> 1 <?php echo e($general->cur_text); ?>

                            = <?php echo e($data->rate*1); ?>  <?php echo e($data->baseCurrency()); ?></span></li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong><?php echo app('translator')->get('Payable'); ?> <?php echo app('translator')->get('In'); ?> <?php echo e($data->baseCurrency()); ?> :</strong> <span
                                class="badge badge-info"><?php echo e(formatter_money($data->final_amo)); ?> <?php echo e($data->baseCurrency()); ?></span>
                    </li>

                    <?php if($data->gateway->crypto==1): ?>
                        <li class="list-group-item  justify-content-start "><strong> <?php echo app('translator')->get('Conversion with'); ?>
                                <b> <?php echo e($data->method_currency); ?> </b> <?php echo app('translator')->get(' and final value will Show on next step'); ?>
                            </strong></li>
                    <?php endif; ?>
                </ul>
                <div class="card-body text-center">
                    <a href="<?php echo e(route('user.deposit.confirm')); ?>" class="btn btn-primary"><?php echo app('translator')->get('Pay Now'); ?></a>
                </div>

            </div>
        </div>

    </div>




<?php $__env->stopSection(); ?>




<?php echo $__env->make(activeTemplate() .'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profpkwf/50dollarbtc.com/core/resources/views/templates/tmp2/payment/preview.blade.php ENDPATH**/ ?>